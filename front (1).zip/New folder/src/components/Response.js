import React from "react";
class Response extends React.Component {
  render() {
    return (
      <div>
        <h1>Thank You For Nothing!...</h1>
        <span>
          Congratulations you have successfyully wasted your time here...
        </span>
      </div>
    );
  }
}

export default Response;
