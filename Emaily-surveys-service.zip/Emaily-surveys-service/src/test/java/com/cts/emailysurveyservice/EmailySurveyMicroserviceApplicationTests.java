package com.cts.emailysurveyservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailySurveyMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
