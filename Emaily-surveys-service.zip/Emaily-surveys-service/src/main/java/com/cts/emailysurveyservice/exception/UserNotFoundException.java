package com.cts.emailysurveyservice.exception;

public class UserNotFoundException extends Exception {

	/**
	 * This is UserNotFoundException contructor
	 * 
	 * @param message
	 */
	public UserNotFoundException(String message) {
		super(message);
	}
}
